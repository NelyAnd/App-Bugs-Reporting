const config = {
  backendAddress: "http://localhost:5000",
};

export default config;
